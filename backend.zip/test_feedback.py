import pytest
from playwright.sync_api import Page, expect

def test_basic_flow(page: Page):
    page.goto("http://localhost:3000/?order_id=TEST001&courier_id=123")
    page.wait_for_load_state("networkidle")
    
    # Check if the header is visible
    expect(page.get_by_role("heading", name="Rate Your Delivery")).to_be_visible()
    
    # Check if the order ID is displayed
    expect(page.locator("text=Order ID: TEST001")).to_be_visible()
    
    # Click on the 5th star to give a 5-star rating
    page.locator('button:nth-child(5) > [data-lucide="star"]').click()
    
    # Fill in the comment
    page.locator("textarea").fill("This is a test comment.")
    
    # Click on the "Punctuality" checkbox
    page.get_by_text("Punctuality").click()
    
    # Click on the consent checkbox
    page.locator("input[type=checkbox]").last.check()
    
    # Click on the submit button
    page.get_by_role("button", name="Submit Feedback").click()
    
    # Check if the thank you message is visible
    expect(page.get_by_role("heading", name="Thank You!")).to_be_visible()

def test_admin_dashboard(page: Page):
    page.goto("http://localhost:3000/admin")
    page.wait_for_load_state("networkidle")
    
    # Check if the login page is visible
    expect(page.get_by_role("heading", name="Admin Login")).to_be_visible()
    
    # Fill in the username and password
    page.locator("input[name=username]").fill("admin")
    page.locator("input[name=password]").fill("admin")
    
    # Click on the login button
    page.get_by_role("button", name="Login").click()
    
    # Check if the admin dashboard is visible
    expect(page.get_by_role("heading", name="Admin Dashboard")).to_be_visible()
    
    # Check if the feedback from the previous test is visible
    expect(page.get_by_text("TEST001")).to_be_visible()
    
    # Click on the CSV export button
    with page.expect_download() as download_info:
        page.get_by_role("button", name="Export CSV").click()
    download = download_info.value
    assert download.suggested_filename.endswith(".csv")

def test_duplicate_prevention(page: Page):
    # First submission
    page.goto("http://localhost:3000/?order_id=TEST002&courier_id=123")
    page.wait_for_load_state("networkidle")
    expect(page.get_by_role("heading", name="Rate Your Delivery")).to_be_visible()
    page.locator('button:nth-child(5) > [data-lucide="star"]').click()
    page.locator("textarea").fill("This is a test comment for duplicate prevention.")
    page.get_by_text("Punctuality").click()
    page.locator("input[type=checkbox]").last.check()
    page.get_by_role("button", name="Submit Feedback").click()
    expect(page.get_by_role("heading", name="Thank You!")).to_be_visible()
    
    # Second submission
    page.goto("http://localhost:3000/?order_id=TEST002&courier_id=123")
    page.wait_for_load_state("networkidle")
    expect(page.get_by_role("heading", name="Already Submitted")).to_be_visible()
